#include "TDA7439.h"
#include "i2c.h"

void setInput(uint8_t input)
{
  switch (input) {
    case 1: input = TDA7439_input_1;break;
	case 2: input = TDA7439_input_2;break;
	case 3: input = TDA7439_input_3;break;
	case 4: input = TDA7439_input_4;break;
  }
  writeWire(TDA7439_input_sel,input);	
}

void inputGain(uint8_t gain)
{
  writeWire(TDA7439_input_gain,gain);
}

void setVolume(uint8_t volume)
{
  if (volume == 0){
    volume = TDA7439_mute;
	}else{
	  volume = 48 - volume;
  }
  writeWire(TDA7439_volume,volume);
}

void setSnd(int8_t val, uint8_t range)
{
  switch (range){
    case 1:range = TDA7439_bass;break;
	case 2:range = TDA7439_middle;break;
	case 3:range = TDA7439_trebble;break;
  }
  switch (val){
    case -7:val = 0;break;
	case -6:val = 1;break;
	case -5:val = 2;break;
	case -4:val = 3;break;
	case -3:val = 4;break;
	case -2:val = 5;break;
	case -1:val = 6;break;
	case 0 :val = 7;break;
	case 1 :val = 14;break;
	case 2 :val = 13;break;
	case 3 :val = 12;break;
	case 4 :val = 11;break;
	case 5 :val = 10;break;
	case 6 :val = 9;break;
	case 7 :val = 8;break;
  }
  writeWire(range,val);
}

void mute()
{
  writeWire(TDA7439_volume,TDA7439_mute);
}

void spkAtt(uint8_t att)
{
  // Mainly used to override the default attenuation of mute at power up
  // can be used for balance with some simple code changes here.
  writeWire(TDA7439_ratt,att);
  writeWire(TDA7439_latt,att);
}

void writeWire(uint8_t a, uint8_t b)
{
  uint8_t outbuffer[2];
  outbuffer[0] = a;
  outbuffer[1] = b;
  HAL_I2C_Master_Transmit(&hi2c1, TDA7439_address<<1, outbuffer, 2, HAL_MAX_DELAY);
}
