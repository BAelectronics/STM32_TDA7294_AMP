/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */


//  eepromConf.h  ->  EEPROM_USE_FLASH_PAGE
//  Minimum: (változó)  Maximum: 64
//  Használva 2020.04 - ? : 55 (jelenlegi)


/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "eeprom.h"
#include "stdio.h"
#include "LCD.h"
#include "TDA7439.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

struct NEC
{
	uint8_t addr;
	uint8_t cmd;
	int8_t i;
	uint8_t init_seq;
	uint8_t gpio;
	uint16_t count;
	uint8_t repeat;
	uint8_t complet;
} NEC1;

struct beallitottertekek
{
	int8_t hangero;
	int8_t bemenet;
	int8_t mely;
	int8_t kozep;
	int8_t magas;
	int8_t eloerosites;
} beallitasok;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

//#define DEBUG_USB_IR
//#define INFO_IR_ADDR
//#define INFO_ADC_FREQ
//#define INFO_EE_SIZE
//#define PROG_EEPROM

#define alapjarat				1020		// Ventilátor alap sebessége, PWM érték (0 - 2878)
#define ventiemel_hatarho   	38			// Ennyi foknál kezdi emelni a venti sebességét
#define ventimax_hatarho    	70			// Ennyi foknál éri el a venti a max sebességet
#define vedelem_hatarho			77			// Ennyi foknál figyelmeztetés és némítás, 3 fokkal meghaladva készenlétbe kapcsolás
#define hoszenzor_offset 		535			// Hőszenzornál 0,5 Voltnál 0C a mért hő, kalibráláshoz módosítandó
#define fenyero_max     		65535		// LCD háttérfény maximális értéke (0 - 65535)
#define visszaall				500			// Kéretlen felébredés után ennyi idővel visszalép készenlétbe [ms]
#define kikapcsutanvar  		300 		// Kikapcsolás utáni leghamarabbi bekapcsolás ideje [ms]
#define bekapcsutanvar  		500      	// Bekapcsolás utáni leghamarabbi kikapcsolás ideje [ms]
#define bekapcsutanMuteDelay	250			// Bekapcsolás utáni némítás feloldás ideje (KISEBB KELL LEGYEN MINT "bekapcsutanvar"!) [ms]
#define adc_buff_meret  		128			// ADC beolvasási tömb elemszáma (hőmérséklet átlagolásnál összes minta darabszám)
#define prell_ido				300			// Nyomógombok kezeléséhez, várakozási idő két nyomás között [ms]
#define enk_prell_ido			25			// Enkóder forgatás prellmentesítéséhez [ms]
#define halvanyulas_ido 		450			// Háttérvilágítás elhalványulási idő hossza [4 * X ms]
#define idoalap					100			// Háttérvilágítás, csík, hosszannyomás időalap [ms]
#define vilagitasido			140			// Háttérvilágítás ideje [idoalap * X ms]
#define csikido					30			// Hangerő állítás csík megjelenítés ideje [idoalap * X ms]
#define hosszannyom_ido			25			// Gomb hosszannyomás érzékelés ideje [idoalap * X ms]
#define max_hangero				48

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

uint32_t elozoMilisec0 = 0;
uint32_t elozoMilisec1 = 0;
uint32_t elozoMilisec2 = 0;
uint32_t elozoMilisec3 = 0;
uint32_t elozoMilisec4 = 0;
uint32_t elozoMilisec5 = 0;
uint32_t elozoMilisec6 = 0;
uint32_t elozoMilisec7 = 0;
uint32_t elozomero = 0;
uint32_t aktualisMilisec0 = 0;
uint32_t aktualisMilisec1 = 0;
uint32_t aktualisMilisec2 = 0;
uint32_t aktualisMilisec3 = 0;
uint32_t aktualisMilisec4 = 0;
uint32_t aktualisMilisec5 = 0;
uint32_t aktualisMilisec6 = 0;
uint32_t aktualisMilisec7 = 0;
uint32_t aktualismero = 0;
uint8_t csik = 0;
uint8_t vissza = 0;
uint8_t menu = 0;
uint8_t hatterfeny_idoszamlalo = 0;
uint16_t hatterfeny_seged = 0;
uint8_t hangero_szamlalo = 0;
uint8_t hangcsikjelzo = 0;
uint8_t almenu1 = 0;
uint8_t almenu_szamlalo = 0;
uint8_t bekapcsolva = 0;
uint8_t mehet = 0;
uint8_t be_kesleltet = 0;
uint8_t lekapcsolt = 0;
uint8_t adc_beolvasott = 0;
uint8_t debug_string_length = 0;
uint16_t var = 0;
uint8_t venti_szazalek = 0;
uint8_t IRfogadott = 0;
uint8_t forog = 0;
uint8_t IRegyJelzo0 = 0;
uint8_t IRegyJelzo1 = 0;
uint16_t IRtobbJelzo0 = 0;
uint16_t IRtobbJelzo1 = 0;
uint16_t pwm_nyers = 0;
uint16_t gomb_off = 0;
uint8_t hiba = 0;
uint8_t szamolunk = 0;
uint8_t standby = 1;
uint32_t kiir_seged = 0;
uint16_t kiir_egesz = 0;
uint8_t kiir_tized = 0;
uint16_t hofok_egesz = 0;
uint16_t adc_atlag = 0;
uint32_t osszes = 0;

float kiir_valos = 0;

uint8_t debug_buff[80];
uint16_t adc_buffer[adc_buff_meret];
int8_t EEsegedtomb[6] = { 0 };

uint8_t ratt_buf[2] = { 0x06, 70 };
uint8_t latt_buf[2] = { 0x07, 70 };

uint8_t mely_jel[8] = { 0b00000,
						0b11111,
						0b11111,
						0b11111,
						0b01110,
						0b00100,
						0b00000,
						0b00000 };

uint8_t kozep_jel[8] = { 0b00000,
						 0b11111,
						 0b01110,
						 0b00100,
						 0b00100,
						 0b01110,
						 0b11111,
						 0b00000 };

uint8_t magas_jel[8] = { 0b00000,
						 0b00100,
						 0b01110,
						 0b11111,
						 0b11111,
						 0b11111,
						 0b00000,
						 0b00000 };

uint8_t korc[8] = { 0b01000,
					0b10100,
					0b01000,
					0b00110,
					0b01001,
					0b01000,
					0b01001,
					0b00110 };

uint8_t felbal[8] = { 0b11111,
					  0b10000,
					  0b10011,
					  0b10010,
					  0b10010,
					  0b10011,
					  0b10000,
					  0b11111 };

uint8_t feljobb[8] = { 0b11111,
					   0b00001,
					   0b11001,
					   0b01001,
					   0b01001,
					   0b11001,
					   0b00001,
					   0b11111 };

char *bemenetek[] = { " ",
					  "> PC <    ",		 // Egyes
					  "> TV <    ",		 // Kettes
					  "> RADIO < ",		 // Hármas
					  "> BLUE <  " };	 // Négyes

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

void be1(void);
void be2(void);
void be3(void);
void be4(void);
void vissza_lepes(void);
void menube_lepes_allitas(void);
void modosit_egyikiranyba(void);
void modosit_masikiranyba(void);
void hattervil_be(void);
void csik_kijelzes(void);
void hangszin_kijelzes(void);
void vissza_gomb_nyomva(void);
void vissza_nyomva(void);
void vissza_forog(void);
void OFF_folyamat(void);
void ON_folyamat(void);
void EEPROM_iras(void);
void EE_olvas_TDA_kuld(void);
void I2C_hibakezeles(void);
int32_t map(int32_t, int32_t, int32_t, int32_t, int32_t);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Instance == TIM1)
	{
		NEC1.addr = 0;
		NEC1.cmd = 0;
		NEC1.gpio = 0;
		NEC1.i = 0;
		NEC1.init_seq = 0;
		if (var >= 20)
		{
			NEC1.repeat = 0;
			var = 0;
		}
		var++;
		NEC1.complet = 0;
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	elozoMilisec2 = aktualisMilisec2;

	if (GPIO_Pin == NEC_Pin)
	{
		NEC1.count = __HAL_TIM_GET_COUNTER(&htim1);
		__HAL_TIM_SET_COUNTER(&htim1, 0);
		NEC1.gpio = HAL_GPIO_ReadPin(NEC_GPIO_Port, NEC_Pin);

		if (NEC1.gpio && NEC1.count > 850 && NEC1.count < 1000)
		{
			NEC1.init_seq = 1;
			NEC1.complet = 0;
			IRtobbJelzo0++;
		}

		if (!NEC1.gpio && NEC1.count > 420 && NEC1.count < 480 && NEC1.init_seq)
		{
			NEC1.i = -1;
			NEC1.repeat = 0;
			NEC1.init_seq = 0;
			IRegyJelzo0++;
		}

		if (!NEC1.gpio && NEC1.count > 200 && NEC1.count < 260 && NEC1.init_seq)
		{
			NEC1.i = -1;
			NEC1.init_seq = 0;
			NEC1.repeat++;
			var = 0;
			NEC1.complet = 1;
		}

		if (NEC1.gpio && NEC1.count > 40 && NEC1.count < 70) NEC1.i++;

		if (!NEC1.gpio && NEC1.count > 40 && NEC1.count < 180)
		{
			switch (NEC1.i / 8)
			{
#ifdef INFO_IR_ADDR
					case 0:
						if (NEC1.count > 100) NEC1.addr |= (1 << (NEC1.i % 8));
						else NEC1.addr &= ~(1 << (NEC1.i % 8));
						break;
#endif
			case 2:
				if (NEC1.count > 100) NEC1.cmd |= (1 << (NEC1.i % 8));
			    else NEC1.cmd &= ~(1 << (NEC1.i % 8));
				break;
			default:
				break;
			}
		}

		if (NEC1.i == 32)
		{
			NEC1.complet = 1;
			IRfogadott = NEC1.cmd;
		}
	}

	if ((bekapcsolva == 1) && ((GPIO_Pin == ENCODER_A_Pin) || (GPIO_Pin == ENCODER_B_Pin))) enkoder_forog();

}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	osszes = 0;
	for (int i = 0; i < adc_buff_meret; i++) osszes = osszes + adc_buffer[i];
	adc_atlag = osszes / adc_buff_meret;
	hofok_egesz = ((adc_atlag - hoszenzor_offset) / 12.2);
	adc_beolvasott = 1;
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	HAL_StatusTypeDef ret;

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_I2C1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();

  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim1);
  HAL_TIM_Base_Start_IT(&htim3);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);		// LCD háttérfény
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);		// Venti PWM


#ifdef INFO_EE_SIZE
    uint16_t mem_max_addr = EE_GetMaximumVirtualAddress();
    uint16_t mem_size = EE_GetSize();
#endif

#ifdef INFO_ADC_FREQ
    uint8_t calculatedADCfreq = ((HAL_RCC_GetSysClockFreq())/htim3.Init.Period)/((htim3.Init.Prescaler)+1);		// Fejlesztéshez [Hz]
#endif


	HAL_Delay(5);
	ret = HAL_I2C_Master_Transmit(&hi2c1, 0x44 << 1, ratt_buf, 2, HAL_MAX_DELAY);
	if (ret != HAL_OK)
	{
		I2C_hibakezeles();
		HAL_I2C_Master_Transmit(&hi2c1, 0x44 << 1, ratt_buf, 2, HAL_MAX_DELAY);
	}
	HAL_I2C_Master_Transmit(&hi2c1, 0x44 << 1, latt_buf, 2, HAL_MAX_DELAY);
	HAL_Delay(5);
	EE_olvas_TDA_kuld();
	HAL_Delay(30);

	/*
	LCD_Init();						// Tartalmaz: init, törlés, várakozás
	LCD_CreateChar(0, mely_jel);
	LCD_CreateChar(1, kozep_jel);
	LCD_CreateChar(2, magas_jel);
	LCD_CreateChar(3, korc);
	LCD_CreateChar(4, felbal);
	LCD_CreateChar(5, feljobb);
	 */

#ifdef PROG_EEPROM
	EE_Format();
	beallitasok.hangero	  	  =  1;
	beallitasok.bemenet 	  =  1;
	beallitasok.mely 		  =  0;
	beallitasok.kozep		  =  0;
	beallitasok.magas 		  =  0;
	beallitasok.eloerosites   =  0;
	EEPROM_iras();
#endif

	HAL_ADC_Start_DMA(&hadc1, (uint32_t*) adc_buffer, adc_buff_meret);
	OFF_folyamat();		// Főkapcsoló felkapcsolás után alapból standby-ba lép

/*
	 HAL_Delay(150);
	 HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
	 HAL_Delay(500);
	 HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
	 HAL_Delay(150);
	 HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
	 HAL_Delay(150);
	 HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
	 HAL_Delay(150);
	 HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
	 HAL_Delay(150);
	 HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
*/

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

	while (1)
	{
		if (standby)		// USB KAPCSOLAT MELLETT NEM MARAD STANDBY ÜZEMMÓDBAN (HA CSATLAKOZTATVA VAN) !!!
		{
			HAL_GPIO_WritePin(MUTE_GPIO_Port, MUTE_Pin, GPIO_PIN_RESET);				// Erősítő HW némítása
			HAL_Delay(kikapcsutanvar + gomb_off);
			standby = 0;
			gomb_off = 0;
			if (bekapcsolva == 1)
			{
				EEPROM_iras();
				OFF_folyamat();
				bekapcsolva = 0;
			}

			NEC1.addr = 0;
			NEC1.cmd = 0;
			NEC1.gpio = 0;
			NEC1.i = 0;
			NEC1.init_seq = 0;
			NEC1.complet = 0;

			HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);					// Panel LED ki
			HAL_GPIO_WritePin(LCD_RS_GPIO_Port, LCD_RS_Pin, GPIO_PIN_RESET);			// Nyomógomb LED halvány világítás megakadályozása
			HAL_GPIO_WritePin(LCD_EN_GPIO_Port, LCD_EN_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(LCD_D4_GPIO_Port, LCD_D4_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(LCD_D5_GPIO_Port, LCD_D5_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(LCD_D6_GPIO_Port, LCD_D6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(LCD_D7_GPIO_Port, LCD_D7_Pin, GPIO_PIN_RESET);
			HAL_SuspendTick();
			HAL_TIM_Base_Stop_IT(&htim1);												// IR fogadás leállítás
			//HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON, PWR_SLEEPENTRY_WFI);
			//HAL_PWR_EnterSTOPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
			HAL_PWR_EnterSLEEPMode(PWR_LOWPOWERREGULATOR_ON, PWR_SLEEPENTRY_WFI);
			//HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
			//SystemClock_Config();
			HAL_TIM_Base_Start_IT(&htim1);												// IR fogadás engedélyezés
			HAL_ResumeTick();
			HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);					// Panel LED be
		}

		if (NEC1.complet && ((NEC1.cmd == 196) || (NEC1.cmd == 159)) && (IRegyJelzo0 != IRegyJelzo1) && (bekapcsolva == 0)) ON_folyamat();
		if (NEC1.complet && bekapcsolva == 0) standby = 1;
		if ((NEC1.complet && (IRtobbJelzo0 != IRtobbJelzo1)	&& (bekapcsolva == 1) && (mehet == 1)))
		{
			switch (NEC1.cmd)
			{
			case 100:	// Bemenet váltás léptetve (telefon IR)
				if (IRegyJelzo0 != IRegyJelzo1)
				{
					if(beallitasok.bemenet == 4) beallitasok.bemenet = 1;
					else beallitasok.bemenet++;
					setInput(beallitasok.bemenet);
					hattervil_be();
					IRegyJelzo1 = IRegyJelzo0;
				}
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 114:
				be1();
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 113:
				be2();
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 99:
				be3();
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 97:
				be4();
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 40:	// Vissza
				vissza_lepes();
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 68:	// Menü
				if (IRegyJelzo0 != IRegyJelzo1)
				{
					menube_lepes_allitas();
					IRegyJelzo1 = IRegyJelzo0;
				}
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 171:	// IR adatok
				menu = 2;
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 69:	// Belső infók
				menu = 3;
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 3:		// Forgat balra
				modosit_egyikiranyba();
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 2:		// Forgat jobbra
				modosit_masikiranyba();
				IRtobbJelzo1 = IRtobbJelzo0;
				break;
			case 159:	// Ki
				standby = 1;
				break;
			case 196:	// Ki (telefon IR)
				standby = 1;
				break;
			default:
				break;
			}
		}

		if (be_kesleltet == 1)				// Bekapcs után késéssel indul az LCD
		{
			HAL_Delay(20);
			LCD_DisplayOff();
			LCD_Init();
			LCD_CreateChar(0, mely_jel);
			LCD_CreateChar(1, kozep_jel);
			LCD_CreateChar(2, magas_jel);
			LCD_CreateChar(3, korc);
			LCD_CreateChar(4, felbal);
			LCD_CreateChar(5, feljobb);

			EE_olvas_TDA_kuld();			// Beállítások kiolvasása és elküldése

			be_kesleltet = 0;
			HAL_Delay(50);
			HAL_GPIO_WritePin(MUTE_GPIO_Port, MUTE_Pin, GPIO_PIN_SET);		// Erősítő HW némítás feloldás
		}

		if (bekapcsolva == 1)
		{
		switch (menu)
		{
		case 0:		// Főképernyő
			LCD_CursorSet(0, 0);
			LCD_PutText(bemenetek[beallitasok.bemenet]);
			if ((hangcsikjelzo == 1) && (beallitasok.hangero == max_hangero))
			{
				LCD_CursorSet(9, 0);
				LCD_PutText("VOL:MAX");
			} else
			{
				LCD_CursorSet(10, 0);
				LCD_PutText("VOL:");
				if (beallitasok.hangero < 10) LCD_PutText(" ");
				LCD_PutVar(beallitasok.hangero);
			}
			if (hangcsikjelzo == 1)	csik_kijelzes();
			else hangszin_kijelzes();
			break;
		case 1:		// Hangszín beállító menü
			hattervil_be();
			hangszin_kijelzes();
			LCD_CursorSet(0, 0);
			switch (almenu1)
			{
			case 0:
				LCD_PutText("BEALLIT: MELY   ");
				break;
			case 1:
				LCD_PutText("BEALLIT: KOZEP  ");
				break;
			case 2:
				LCD_PutText("BEALLIT: MAGAS  ");
				break;
			default:
				break;
			}
			break;
		case 2:		// Infravevő olvasó menü
			LCD_CursorSet(0, 0);
			LCD_PutText("INFRAVEVO ADATOK");
			LCD_CursorSet(0, 1);
			LCD_PutText("IR: >");
			LCD_PutVar(IRfogadott);
			LCD_PutText("< rep:");
			LCD_PutVar(NEC1.repeat);
			LCD_PutText("   ");
			hattervil_be();
			break;
		case 3:		// Információs menü
			if (adc_beolvasott == 1)			// Frissíti a kijelzést ha kész az ADC
			{
				kiir_valos = ((adc_atlag - hoszenzor_offset) / 12.2);
				kiir_seged = kiir_valos * 1000;
				kiir_tized = (kiir_seged % 1000) / 100;
				LCD_Clear();
				LCD_CursorSet(0, 0);
				LCD_PutVar(hofok_egesz);
				if (hofok_egesz < 100)
				{
					LCD_PutText(".");
					LCD_PutVar(kiir_tized);
				}
				LCD_PutCustom(3);
				kiir_valos = adc_atlag / 1222.0;
				kiir_seged = kiir_valos * 1000;
				kiir_egesz = kiir_seged / 1000;
				kiir_tized = (kiir_seged % 1000) / 10;
				LCD_CursorSet(6, 0);
				LCD_PutVar(kiir_egesz);
				LCD_PutText(".");
				if (kiir_tized < 10) LCD_PutText("0");
				LCD_PutVar(kiir_tized);
				LCD_PutText("V ");
				LCD_CursorSet(12, 0);
				LCD_PutVar(adc_atlag);
				LCD_PutText("   ");
				LCD_CursorSet(0, 1);
				LCD_PutCustom(4);
				LCD_PutCustom(5);
				LCD_PutVar(venti_szazalek);
				LCD_PutText("%");
				LCD_CursorSet(6, 1);
				LCD_PutText("v:20.09.03");
				hattervil_be();
				adc_beolvasott = 0;
			}
			break;
		case 4:		// Hővédelem menü (auto)
			kiir_valos = ((adc_atlag - hoszenzor_offset) / 12.2);
			kiir_seged = kiir_valos * 1000;
			kiir_tized = (kiir_seged % 1000) / 100;
			LCD_CursorSet(0, 0);
			LCD_PutText("FIGYELEM! ");
			LCD_PutVar(hofok_egesz);
			if (hofok_egesz < 100)
			{
				LCD_PutText(".");
				LCD_PutVar(kiir_tized);
			}
			LCD_PutCustom(3);
			LCD_PutText(" ");
			LCD_CursorSet(0, 1);
			LCD_PutText("OFF:");
			LCD_PutVar(vedelem_hatarho + 4);
			LCD_PutCustom(3);
			LCD_PutText(" OK:<");
			LCD_PutVar(vedelem_hatarho);
			LCD_PutCustom(3);
			LCD_PutText(" ");
			hattervil_be();
			break;
		default:
			break;
		}
		}


		aktualisMilisec2 = HAL_GetTick();
		if (((aktualisMilisec2 - elozoMilisec2) >= visszaall) && (bekapcsolva == 0))		// Fals ébredés utáni visszaalvás lekezelés
		{
			standby = 1;
			elozoMilisec2 = aktualisMilisec2;
		}

		if ((beallitasok.bemenet == 4) && (bekapcsolva == 1) && (hiba == 0)) HAL_GPIO_WritePin(BLUE_GPIO_Port, BLUE_Pin, GPIO_PIN_SET);
		else HAL_GPIO_WritePin(BLUE_GPIO_Port, BLUE_Pin, GPIO_PIN_RESET);

		aktualismero = HAL_GetTick();
		if ((aktualismero - elozomero) >= bekapcsutanvar)
		{
			mehet = 1;
			elozomero = aktualismero;
		}

		aktualisMilisec7 = HAL_GetTick();
		if (aktualisMilisec7 - elozoMilisec7 >= 5)		// Prell és zavar ellen
		{
			if (((HAL_GPIO_ReadPin(ENCODER_K_GPIO_Port, ENCODER_K_Pin)) == 0)
					   || ((HAL_GPIO_ReadPin(ON_OFF_GPIO_Port, ON_OFF_Pin)) == 0)
			           || ((HAL_GPIO_ReadPin(IN_1_GPIO_Port, IN_1_Pin)) == 0)
					   || ((HAL_GPIO_ReadPin(IN_2_GPIO_Port, IN_2_Pin)) == 0)
					   || ((HAL_GPIO_ReadPin(IN_3_GPIO_Port, IN_3_Pin)) == 0)
					   || ((HAL_GPIO_ReadPin(IN_4_GPIO_Port, IN_4_Pin)) == 0)
					   || ((HAL_GPIO_ReadPin(BACK_GPIO_Port, BACK_Pin)) == 0)) szamolunk++;
			if (((HAL_GPIO_ReadPin(ENCODER_K_GPIO_Port, ENCODER_K_Pin)) == 1)
					   &&  ((HAL_GPIO_ReadPin(ON_OFF_GPIO_Port, ON_OFF_Pin)) == 1)
					   &&  ((HAL_GPIO_ReadPin(IN_1_GPIO_Port, IN_1_Pin)) == 1)
					   &&  ((HAL_GPIO_ReadPin(IN_2_GPIO_Port, IN_2_Pin)) == 1)
					   &&  ((HAL_GPIO_ReadPin(IN_3_GPIO_Port, IN_3_Pin)) == 1)
					   &&  ((HAL_GPIO_ReadPin(IN_4_GPIO_Port, IN_4_Pin)) == 1)
					   &&  ((HAL_GPIO_ReadPin(BACK_GPIO_Port, BACK_Pin)) == 1)
					   && (szamolunk > 0) && (szamolunk < 8)) szamolunk = 0;
			if (szamolunk >= 7)							// 5x7=35ms ideig nyomott gombot érzékel, rövidebb nyomást nem
			{
				if ((HAL_GPIO_ReadPin(ENCODER_K_GPIO_Port, ENCODER_K_Pin)) == 0) enkoder_nyomva();
				if (((HAL_GPIO_ReadPin(ON_OFF_GPIO_Port, ON_OFF_Pin)) == 0) && (mehet == 1) && (bekapcsolva == 1)) standby = 1;
				if (((HAL_GPIO_ReadPin(ON_OFF_GPIO_Port, ON_OFF_Pin)) == 0) && (bekapcsolva == 0)) ON_folyamat();
				if ((HAL_GPIO_ReadPin(IN_1_GPIO_Port, IN_1_Pin)) == 0) be1();
				if ((HAL_GPIO_ReadPin(IN_2_GPIO_Port, IN_2_Pin)) == 0) be2();
				if ((HAL_GPIO_ReadPin(IN_3_GPIO_Port, IN_3_Pin)) == 0) be3();
				if ((HAL_GPIO_ReadPin(IN_4_GPIO_Port, IN_4_Pin)) == 0) be4();
				if ((HAL_GPIO_ReadPin(BACK_GPIO_Port, BACK_Pin)) == 0) vissza_gomb_nyomva();
				szamolunk = 0;
			}
			elozoMilisec7 = aktualisMilisec7;
		}

		aktualisMilisec3 = HAL_GetTick();
		if (aktualisMilisec3 - elozoMilisec3 >= idoalap)
		{
			if (((HAL_GPIO_ReadPin(ENCODER_K_GPIO_Port, ENCODER_K_Pin)) == 0)
			           || ((HAL_GPIO_ReadPin(BACK_GPIO_Port, BACK_Pin)) == 0)
					   || ((HAL_GPIO_ReadPin(IN_1_GPIO_Port, IN_1_Pin)) == 0)) almenu_szamlalo++;

			if (((HAL_GPIO_ReadPin(ENCODER_K_GPIO_Port, ENCODER_K_Pin)) == 1)
					   && ((HAL_GPIO_ReadPin(BACK_GPIO_Port, BACK_Pin)) == 1)
					   && ((HAL_GPIO_ReadPin(IN_1_GPIO_Port, IN_1_Pin)) == 1)
			           && (almenu_szamlalo > 0) && (almenu_szamlalo < hosszannyom_ido)) almenu_szamlalo = 0;
			if (almenu_szamlalo >= hosszannyom_ido)
			{
				if ((HAL_GPIO_ReadPin(ENCODER_K_GPIO_Port, ENCODER_K_Pin)) == 0) menu = 2;		// Enkóder hosszannyomás
				if ((HAL_GPIO_ReadPin(BACK_GPIO_Port, BACK_Pin)) == 0) menu = 3;				// Visszagomb hosszannyomás
				if ((HAL_GPIO_ReadPin(IN_1_GPIO_Port, IN_1_Pin)) == 0)							// 1-es bemenet hosszannyomás
				{
					mute();
					HAL_GPIO_WritePin(MUTE_GPIO_Port, MUTE_Pin, GPIO_PIN_RESET);				// Erősítő HW némítása
					beallitasok.hangero = 0;
					EEPROM_iras();
					__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 2878);							// Venti tisztítás, némít+ment, végtelen ciklus
					__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, fenyero_max);
					LCD_CursorSet(0, 0);
					LCD_PutText("   VENTILATOR   ");
					LCD_CursorSet(0, 1);
					LCD_PutText("TISZTITAS AKTIV ");
					while(1) asm("NOP");
				}
				almenu_szamlalo = 0;
				hattervil_be();
			}
			elozoMilisec3 = aktualisMilisec3;
		}

		aktualisMilisec1 = HAL_GetTick();
		if ((aktualisMilisec1 - elozoMilisec1 >= idoalap) && (hatterfeny_idoszamlalo < vilagitasido))
		{
			hatterfeny_idoszamlalo++;
			elozoMilisec1 = aktualisMilisec1;
		}

		aktualisMilisec6 = HAL_GetTick();
		if ((hatterfeny_idoszamlalo >= vilagitasido) && !lekapcsolt && ((aktualisMilisec6 - elozoMilisec6) >= 4))
		{
			hatterfeny_seged++;
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, map(hatterfeny_seged, 0, halvanyulas_ido, fenyero_max, 0));

			if (hatterfeny_seged == halvanyulas_ido)
			{
				hatterfeny_seged = 0;
				hatterfeny_idoszamlalo = 0;
				lekapcsolt = 1;
			}
			elozoMilisec6 = aktualisMilisec6;
		}

		aktualisMilisec0 = HAL_GetTick();
		if ((aktualisMilisec0 - elozoMilisec0 >= idoalap) && (hangero_szamlalo < csikido))
		{
			hangero_szamlalo++;
			elozoMilisec0 = aktualisMilisec0;
		}
		if (hangero_szamlalo >= csikido)
		{
			hangcsikjelzo = 0;
			hangero_szamlalo = 0;
		}

		if (hofok_egesz < ventiemel_hatarho) pwm_nyers = alapjarat;
		else if (hofok_egesz <= ventimax_hatarho) pwm_nyers = map(hofok_egesz, ventiemel_hatarho, ventimax_hatarho, alapjarat, 2878);
		else pwm_nyers = 2878;
		venti_szazalek = map(pwm_nyers, 0, 2878, 0, 99);
		__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, pwm_nyers);

		if ((hofok_egesz > vedelem_hatarho) && (adc_beolvasott == 1))
		{
			mute();
			HAL_GPIO_WritePin(MUTE_GPIO_Port, MUTE_Pin, GPIO_PIN_RESET);
			beallitasok.hangero = 0;
			hiba = 1;
			menu = 4;
			adc_beolvasott = 0;
			if (hofok_egesz > vedelem_hatarho + 2) standby = 1;
		}
		if ((hofok_egesz < vedelem_hatarho) && (hiba == 1))
		{
			HAL_GPIO_WritePin(MUTE_GPIO_Port, MUTE_Pin, GPIO_PIN_SET);
			hiba = 0;
			menu = 0;
		}

#ifdef DEBUG_USB_IR
		if (NEC1.complet)
		{


			if (!NEC1.repeat) {
				debug_string_length =
						sprintf(debug_buff,
								"Received:\n\r\ ADDR:\t%d\n\r\ CMD:\t%d\n\r",
								NEC1.addr, NEC1.cmd);
			} else {
				debug_string_length = sprintf(debug_buff, "Repeat: %d\n\r", NEC1.repeat);
			}
			CDC_Transmit_FS(debug_buff, debug_string_length);

		}
#endif

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV8;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

int32_t map(int32_t x, int32_t in_min, int32_t in_max, int32_t out_min,	int32_t out_max)
{
	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void EE_olvas_TDA_kuld(void)
{
	EE_Reads(1, 6, EEsegedtomb);
	beallitasok.hangero 	 = EEsegedtomb[0];
	beallitasok.bemenet 	 = EEsegedtomb[1];
	beallitasok.mely    	 = EEsegedtomb[2];
	beallitasok.kozep 		 = EEsegedtomb[3];
	beallitasok.magas 		 = EEsegedtomb[4];
	beallitasok.eloerosites  = EEsegedtomb[5];

	setInput(beallitasok.bemenet);			// 1 ... 4
	HAL_Delay(1);
	inputGain(beallitasok.eloerosites); 	// 0 ... 30
	HAL_Delay(1);
	setVolume(beallitasok.hangero);     	// 0 ... 48 ( 0 -> némítás )
	HAL_Delay(1);
	setSnd(beallitasok.mely, 1);			// Mély  (1)
	HAL_Delay(1);
	setSnd(beallitasok.kozep, 2);			// Közép (2)
	HAL_Delay(1);
	setSnd(beallitasok.magas, 3);			// Magas (3)
	HAL_Delay(1);
	spkAtt(0);								// Kimeneti csillapítás kikapcs, némítás feloldása	(0 ... 79db)
	HAL_Delay(1);
}

void EEPROM_iras(void)
{
	EE_Format();
	memcpy(EEsegedtomb, &beallitasok, 6);
	EE_Writes(1, 6, EEsegedtomb);
}

void vissza_gomb_nyomva(void)
{
	aktualisMilisec4 = HAL_GetTick();
	if (aktualisMilisec4 - elozoMilisec4 >= prell_ido)
	{
		vissza_lepes();
		elozoMilisec4 = aktualisMilisec4;
	}
}

void enkoder_nyomva(void)
{
	aktualisMilisec4 = HAL_GetTick();

	if (aktualisMilisec4 - elozoMilisec4 >= prell_ido)
	{
		menube_lepes_allitas();
		elozoMilisec4 = aktualisMilisec4;
	}

}

void enkoder_forog(void)
{
	aktualisMilisec5 = HAL_GetTick();
	if (aktualisMilisec5 - elozoMilisec5 >= enk_prell_ido)
	{
		if (HAL_GPIO_ReadPin(ENCODER_A_GPIO_Port, ENCODER_A_Pin) && !HAL_GPIO_ReadPin(ENCODER_B_GPIO_Port, ENCODER_B_Pin))
		{
			forog = 1;
			modosit_egyikiranyba();
			forog = 0;
		} else if (HAL_GPIO_ReadPin(ENCODER_B_GPIO_Port, ENCODER_B_Pin)	&& !HAL_GPIO_ReadPin(ENCODER_A_GPIO_Port, ENCODER_A_Pin))
			{
				forog = 1;
				modosit_masikiranyba();
				forog = 0;
			}
		elozoMilisec5 = aktualisMilisec5;
	}
}

void menube_lepes_allitas(void)
{
	if (menu == 0) menu = 1;
	if ((menu == 1) && (almenu1 == 2)) almenu1 = 0;
	else if ((menu == 1) && (almenu1 < 2)) almenu1++;
	if (menu == 3) menu = 0;
	hattervil_be();
}

void vissza_lepes(void)
{
	if (menu < 3) menu = 0;
	hangcsikjelzo = 0;
	hattervil_be();
}

void modosit_egyikiranyba(void)
{
	if ((IRegyJelzo0 != IRegyJelzo1) || forog)
	{
		if ((menu == 1) && (almenu1 == 0) && (beallitasok.mely > -7))
		{
			beallitasok.mely--;
			setSnd(beallitasok.mely, 1);
		}
		if ((menu == 1) && (almenu1 == 1) && (beallitasok.kozep > -7))
		{
			beallitasok.kozep--;
			setSnd(beallitasok.kozep, 2);
		}
		if ((menu == 1) && (almenu1 == 2) && (beallitasok.magas > -7))
		{
			beallitasok.magas--;
			setSnd(beallitasok.magas, 3);
		}
		IRegyJelzo1 = IRegyJelzo0;
	}
	if (menu == 0) hangero_le();
	hattervil_be();
}

void modosit_masikiranyba(void)
{
	if (IRegyJelzo0 != IRegyJelzo1 || forog)
	{
		if ((menu == 1) && (almenu1 == 0) && (beallitasok.mely < 7))
		{
			beallitasok.mely++;
			setSnd(beallitasok.mely, 1);
		}
		if ((menu == 1) && (almenu1 == 1) && (beallitasok.kozep < 7))
		{
			beallitasok.kozep++;
			setSnd(beallitasok.kozep, 2);
		}
		if ((menu == 1) && (almenu1 == 2) && (beallitasok.magas < 7))
		{
			beallitasok.magas++;
			setSnd(beallitasok.magas, 3);
		}
		IRegyJelzo1 = IRegyJelzo0;
	}
	if (menu == 0) hangero_fel();
	hattervil_be();
}

void hangero_fel(void)
{
	if (beallitasok.hangero < max_hangero) beallitasok.hangero++;
	setVolume(beallitasok.hangero);
	hangero_szamlalo = 0;
	hangcsikjelzo = 1;
}

void hangero_le(void)
{
	if (beallitasok.hangero > 0) beallitasok.hangero--;
	setVolume(beallitasok.hangero);
	hangero_szamlalo = 0;
	hangcsikjelzo = 1;
}

void be1(void)
{
	beallitasok.bemenet = 1;
	setInput(beallitasok.bemenet);
	hattervil_be();
}

void be2(void)
{
	beallitasok.bemenet = 2;
	setInput(beallitasok.bemenet);
	hattervil_be();
}

void be3(void)
{
	beallitasok.bemenet = 3;
	setInput(beallitasok.bemenet);
	hattervil_be();
}

void be4(void)
{
	beallitasok.bemenet = 4;
	setInput(beallitasok.bemenet);
	hattervil_be();
}

void hattervil_be(void)					// LCD háttérvilágítás bekapcs és kikapcsolási időzítő indítás
{
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, fenyero_max);
	lekapcsolt = 0;
	hatterfeny_idoszamlalo = 0;
	hatterfeny_seged = 0;
}

void hangszin_kijelzes(void)
{
	LCD_CursorSet(0, 1);
	LCD_PutCustom(0);
	LCD_PutText(":");
	if (beallitasok.mely > 0)   LCD_PutText("+");
	if (beallitasok.mely == 0)  LCD_PutText("0");
	LCD_PutVar(beallitasok.mely);
	LCD_PutText("  ");
	LCD_PutCustom(1);
	LCD_PutText(":");
	if (beallitasok.kozep > 0)  LCD_PutText("+");
	if (beallitasok.kozep == 0)	LCD_PutText("0");
	LCD_PutVar(beallitasok.kozep);
	LCD_PutText("  ");
	LCD_PutCustom(2);
	LCD_PutText(":");
	if (beallitasok.magas > 0)  LCD_PutText("+");
	if (beallitasok.magas == 0)	LCD_PutText("0");
	LCD_PutVar(beallitasok.magas);
}

void csik_kijelzes(void)
{
	csik = map(beallitasok.hangero, 0, max_hangero, 0, 16);
	LCD_CursorSet(0, 1);
	for (int k = 0; k < csik; k++) LCD_Put(61);					// 61 --> "="
	for (int k = 0; k < (16 - csik); k++) LCD_Put(32);			// 32 --> " "
}

void OFF_folyamat(void)
{
	HAL_GPIO_WritePin(PERIP_GPIO_Port, PERIP_Pin, GPIO_PIN_RESET);				// Perifériák kikapcsolás
	HAL_GPIO_WritePin(BLUE_GPIO_Port, BLUE_Pin, GPIO_PIN_RESET);				// Bluetooth kikapcsolás
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 0);							// Ventilátor sebesség nullázás
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);							// LCD háttérfény kikapcsolás
	HAL_TIM_Base_Stop_IT(&htim3);												// ADC hívás tiltás
	HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);									// LCD háttérfény tiltás
	HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_2);									// Ventilátor tiltás
}

void ON_folyamat(void)
{
	HAL_GPIO_WritePin(PERIP_GPIO_Port, PERIP_Pin, GPIO_PIN_SET);				// Perifériák bekapcsolása
	HAL_TIM_Base_Start_IT(&htim3);												// ADC hívás engedélyezés
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);									// Ventilátor engedélyezés
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);									// LCD háttérfény engedélyezés
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, pwm_nyers);					// Ventilátor sebesség beállítás
	hattervil_be();																// LCD háttérfény felkapcsolás, időzítők beállítása

	bekapcsolva = 1;															// Bekapcsolt állapot jelzése
	elozomero = aktualismero;
	mehet = 0;																	// Bekapcs után rögtön kikapcs tiltás
	be_kesleltet = 1;															// Perifériák bekapcsolásának késleltetése
}

void I2C_hibakezeles(void)
{
		GPIO_InitTypeDef GPIO_InitStruct = { 0 };

		hi2c1.Instance->CR1 &= ~(0x0001);	// Disable the I2C peripheral by clear the PE bit in I2Cx_CR1 register

		GPIO_InitStruct.Pin = GPIO_PIN_8 | GPIO_PIN_9;	// Configure the SCL and SDA I/Os as General Purpose Output Open-Drain, High level
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
		while (GPIO_PIN_SET != HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8))	// Check SCL High level
		{
			asm("NOP");
		}

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);
		while (GPIO_PIN_SET != HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9))	// Check SDA High level
		{
			asm("NOP");
		}

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);	// Configure the SDA to Low level
		while (GPIO_PIN_RESET != HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9))	// Check SDA Low level
		{
			asm("NOP");
		}

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);	// Configure the SCL to Low level
		while (GPIO_PIN_RESET != HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8))	// Check SCL Low level
		{
			asm("NOP");
		}

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);		// Configure the SCL to High level
		while (GPIO_PIN_SET != HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8))		// Check SCL High level
		{
			asm("NOP");
		}

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);		// Configure the SDA to High level
		while (GPIO_PIN_SET != HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9))		// Check SDA High level
		{
			asm("NOP");
		}

		GPIO_InitStruct.Pin = GPIO_PIN_8 | GPIO_PIN_9;	// Configure the SCL and SDA I/Os as Alternate function Open-Drain
		GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
		HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
/*
		hi2c1.Instance->CR1 |= 0x8000;		// Set SWRST bit in I2Cx_CR1 register
		HAL_Delay(5);

		hi2c1.Instance->CR1 &= ~0x8000;		// Clear SWRST bit in I2Cx_CR1 register
		HAL_Delay(5);
*/
		hi2c1.Instance->CR1 |= 0x0001;		// Enable the I2C peripheral by setting the PE bit in I2Cx_CR1 register
		HAL_Delay(5);

		HAL_I2C_Init(&hi2c1);				// Call initialization function
		HAL_Delay(5);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
